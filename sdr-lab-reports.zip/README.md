# SDR Laboratory Reports

An English-language static website for https://github.com/hodast79/sdr-lab-reports.
The home page introduces the experiment and links to the full PDF report. Report text, calculations, and results stay inside the PDF.

## Publish the website

1. Upload `index.html`, the `assets` folder, and the `lab02` folder into the repository root. Upload the extracted contents, not the ZIP or an enclosing folder.
2. Go to **Settings → Pages**.
3. Under **Build and deployment → Source**, select **Deploy from a branch**.
4. Select **main** and **/ (root)**, then **Save**.
5. Wait for GitHub Pages to deploy. The intended address is https://hodast79.github.io/sdr-lab-reports/.

Official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Add your report

Upload the completed PDF to `lab02/prelab.pdf` (exact lowercase spelling).
The site checks for this file and automatically enables the View PDF Report and Download PDF links. Until then, the page clearly says the PDF is pending. No report PDF is included yet because the completed results document has not been provided.

Once uploaded and deployed, the report address will be:
https://hodast79.github.io/sdr-lab-reports/lab02/prelab.pdf

To replace the report later, upload the new PDF at the same path and commit the change.

## Edit the website

- `index.html`: site text, report card, and links.
- `assets/styles.css`: desktop and mobile layout.
- `assets/site.js`: checks for the PDF and enables its links.
- `assets/favicon.svg`: site icon.
- `lab02/README.md`: reminder of where to upload the PDF.

No build tools or backend are required. Optional Google Fonts fall back to system fonts when offline. There is no analytics, sign-in, or data collection in this site.

## Local preview

Run `python3 -m http.server 8080` from this directory, then open http://localhost:8080/.
Opening index.html directly also shows the website, but PDF availability is checked only when served over HTTP or HTTPS.

## Content

The spectrum illustration is a schematic, not measured data. Topic descriptions are based on the instructor-provided Lab 02 guide, Noise Figure, P1dB and IIP3. This website is a PDF report hub, not a completed pre-lab submission.
